"use client";

import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FiUploadCloud, FiX, FiFilm, FiCheck, FiPlay } from "react-icons/fi";
import { useStore } from "@/store";

const VALID_TYPES = ["video/mp4", "video/quicktime", "video/webm", "video/x-matroska", "video/mpeg"];
const MAX_SIZE = 2 * 1024 * 1024 * 1024; // 2GB

const STAGES = [
  "Uploading",
  "Analyzing",
  "Detecting Scenes",
  "Detecting Faces",
  "Cleaning Audio",
  "Removing Silence",
  "Applying Effects",
  "Color Grading",
  "Generating Captions",
  "Stabilizing",
  "Rendering",
  "Compressing",
];

export default function UploadZone() {
  const { videos, addVideo, removeVideo, updateVideoStatus, clearVideos } = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback((files: FileList | File[]) => {
    Array.from(files).forEach((file) => {
      const isValid = VALID_TYPES.includes(file.type) || file.name.match(/\.(mp4|mov|webm|mkv)$/i);
      if (!isValid || file.size > MAX_SIZE) return;
      addVideo(file);
    });
  }, [addVideo]);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback(() => setIsDragging(false), []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  const onFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) handleFiles(e.target.files);
  }, [handleFiles]);

  const simulateProcessing = useCallback(async () => {
    if (videos.length === 0) return;
    setProcessing(true);
    const videoIds = videos.map((v) => v.id);

    for (let s = 0; s < STAGES.length; s++) {
      const progress = Math.round(((s + 1) / STAGES.length) * 100);
      for (const vid of videoIds) {
        updateVideoStatus(vid, {
          status: "analyzing",
          stage: STAGES[s],
          progress,
        });
      }
      await new Promise((r) => setTimeout(r, 400));
    }

    for (const vid of videoIds) {
      updateVideoStatus(vid, {
        status: "completed",
        stage: "Completed!",
        progress: 100,
      });
    }

    setProcessing(false);
  }, [videos, updateVideoStatus]);

  const formatSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div>
      <div
        className={`relative border-2 border-dashed rounded-2xl p-8 md:p-12 text-center transition-all duration-300 cursor-pointer ${
          isDragging
            ? "border-brand-400 bg-brand-500/10"
            : "border-surface-700 hover:border-brand-500/50 hover:bg-surface-800/50"
        }`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
        role="button"
        tabIndex={0}
        aria-label="Upload videos"
        onKeyDown={(e) => e.key === "Enter" && fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          multiple
          className="hidden"
          onChange={onFileSelect}
          aria-hidden="true"
        />

        <motion.div
          animate={isDragging ? { scale: 1.1 } : { scale: 1 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          <FiUploadCloud className={`w-12 h-12 mx-auto mb-4 ${isDragging ? "text-brand-400" : "text-surface-500"}`} />
          <h3 className="text-lg font-semibold mb-2">
            {isDragging ? "Drop your videos here" : "Drag & Drop Videos Here"}
          </h3>
          <p className="text-sm text-surface-400 mb-4">
            or <span className="text-brand-400 underline">click to browse</span>
          </p>
          <p className="text-xs text-surface-500">
            MP4, MOV, WebM, MKV — Max 2GB per file
          </p>
        </motion.div>
      </div>

      {/* Video queue */}
      <AnimatePresence>
        {videos.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mt-6 space-y-3"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-surface-300">
                {videos.length} video{videos.length !== 1 ? "s" : ""} in queue
              </h4>
              <div className="flex items-center gap-2">
                {processing ? (
                  <span className="text-xs text-surface-500">Processing...</span>
                ) : (
                  <>
                    <button
                      onClick={clearVideos}
                      className="px-3 py-1.5 rounded-lg text-xs text-surface-400 hover:text-accent-rose transition-colors"
                    >
                      Clear All
                    </button>
                    <button
                      onClick={simulateProcessing}
                      className="px-4 py-2 rounded-lg bg-gradient-to-r from-brand-600 to-accent-blue text-white text-sm font-semibold hover:opacity-90 transition-all"
                    >
                      Process All
                    </button>
                  </>
                )}
              </div>
            </div>

            {videos.map((video) => (
              <motion.div
                key={video.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card p-4 flex flex-col sm:flex-row items-start sm:items-center gap-4"
              >
                <div className="w-12 h-12 rounded-lg bg-surface-800 flex items-center justify-center flex-shrink-0">
                  {video.status === "completed" ? (
                    <FiCheck className="w-6 h-6 text-accent-green" />
                  ) : (
                    <FiFilm className="w-6 h-6 text-surface-500" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium truncate">{video.name}</p>
                    <span className="text-xs text-surface-500 ml-2">{formatSize(video.size)}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {video.status !== "completed" && (
                      <span className="text-xs text-brand-400">#{video.queuePosition + 1} — {video.stage}</span>
                    )}
                    {video.status === "completed" && (
                      <span className="text-xs text-accent-green flex items-center gap-1">
                        <FiCheck className="w-3 h-3" /> Ready to download
                      </span>
                    )}
                    <button
                      onClick={() => removeVideo(video.id)}
                      className="text-xs text-surface-500 hover:text-accent-rose transition-colors ml-auto"
                    >
                      Remove
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full sm:w-32 flex-shrink-0">
                  <div className="h-1.5 bg-surface-700 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${
                        video.status === "completed" ? "bg-accent-green" :
                        video.status === "failed" ? "bg-accent-rose" :
                        "bg-gradient-to-r from-brand-500 to-accent-blue"
                      }`}
                      animate={{ width: `${video.progress}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  <span className="text-xs text-surface-500 mt-0.5 block">{video.progress}%</span>
                </div>
              </motion.div>
            ))}

            {processing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center text-sm text-brand-400"
              >
                <div className="flex items-center justify-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" style={{ animationDelay: "0.1s" }} />
                  <div className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" style={{ animationDelay: "0.2s" }} />
                  <span>AI is processing your videos...</span>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
