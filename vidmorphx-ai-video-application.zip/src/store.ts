import { create } from "zustand";
import { v4 as uuidv4 } from "uuid";

interface VideoItem {
  id: string;
  file: File;
  name: string;
  size: number;
  progress: number;
  status: "uploading" | "queued" | "analyzing" | "editing" | "rendering" | "completed" | "failed" | "cancelled";
  stage: string;
  queuePosition: number;
  thumbnail?: string;
}

interface StoreState {
  user: {
    id?: number;
    name?: string;
    email?: string;
    credits?: number;
    storageUsed?: string;
  } | null;
  videos: VideoItem[];
  notifications: { id: string; type: string; message: string }[];
  isLoggedIn: boolean;
  theme: "dark";
  currentView: "home" | "dashboard" | "upload" | "pricing";

  setUser: (user: StoreState["user"]) => void;
  logout: () => void;
  addVideo: (file: File, name?: string) => void;
  removeVideo: (id: string) => void;
  updateVideoStatus: (id: string, updates: Partial<VideoItem>) => void;
  clearVideos: () => void;
  addNotification: (type: string, message: string) => void;
  removeNotification: (id: string) => void;
  setView: (view: StoreState["currentView"]) => void;
  useCredit: () => void;
}

export const useStore = create<StoreState>((set) => ({
  user: null,
  videos: [],
  notifications: [],
  isLoggedIn: false,
  theme: "dark",
  currentView: "home",

  setUser: (user) => set({ user, isLoggedIn: true }),
  logout: () => set({ user: null, isLoggedIn: false }),
  addVideo: (file, name) =>
    set((state) => ({
      videos: [...state.videos, {
        id: uuidv4(),
        file,
        name: name || file.name,
        size: file.size,
        progress: 0,
        status: "queued",
        stage: "Waiting in queue",
        queuePosition: state.videos.length + 1,
      }],
    })),
  removeVideo: (id) =>
    set((state) => ({
      videos: state.videos.filter((v) => v.id !== id),
    })),
  updateVideoStatus: (id, updates) =>
    set((state) => ({
      videos: state.videos.map((v) => (v.id === id ? { ...v, ...updates } : v)),
    })),
  clearVideos: () => set({ videos: [] }),
  addNotification: (type, message) =>
    set((state) => ({
      notifications: [...state.notifications, { id: uuidv4(), type, message }],
    })),
  removeNotification: (id) =>
    set((state) => ({
      notifications: state.notifications.filter((n) => n.id !== id),
    })),
  setView: (view) => set({ currentView: view }),
  useCredit: () =>
    set((state) => ({
      user: state.user ? { ...state.user, credits: Math.max(0, (state.user.credits || 0) - 1) } : null,
    })),
}));
