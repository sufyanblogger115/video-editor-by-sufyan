"use client";

import { useStore } from "@/store";
import Link from "next/link";
import {
  FiVideo, FiClock, FiHardDrive, FiCreditCard, FiBell,
  FiSettings, FiDownload, FiTrash2, FiPlay, FiX, FiCheck,
  FiBarChart2, FiCpu, FiRefreshCw, FiPauseCircle, FiPlayCircle,
  FiKey, FiUser
} from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const mockVideos = [
  { id: "1", name: "product-demo.mp4", size: "245 MB", status: "completed", progress: 100, duration: "3:24", uploaded: "2 hours ago", thumbnail: "green" },
  { id: "2", name: "vlog-day-15.mp4", size: "1.2 GB", status: "processing", progress: 67, duration: "12:08", uploaded: "30 min ago", thumbnail: "blue" },
  { id: "3", name: "tutorial-edit.mov", size: "540 MB", status: "queued", progress: 0, duration: "8:45", uploaded: "Just now", thumbnail: "gray" },
  { id: "4", name: "interview-raw.mp4", size: "2.1 GB", status: "completed", progress: 100, duration: "18:30", uploaded: "Yesterday", thumbnail: "green" },
  { id: "5", name: "b-roll-set.webm", size: "890 MB", status: "failed", progress: 45, duration: "5:12", uploaded: "Yesterday", thumbnail: "red" },
];

export default function DashboardPage() {
  const { user, setUser, isLoggedIn, logout } = useStore();
  const [activeTab, setActiveTab] = useState<"queue" | "history" | "settings">("queue");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (!isLoggedIn) {
      setUser({ id: 1, name: "Alex Morgan", email: "alex@example.com", credits: 25, storageUsed: "4.2" });
    }
  }, [isLoggedIn, setUser]);

  const storagePercent = user?.storageUsed ? Math.min(100, (parseFloat(user.storageUsed) / 50) * 100) : 0;

  const filteredVideos = mockVideos.filter((v) =>
    v.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">
              Dashboard <span className="gradient-text">— {user?.name || "User"}</span>
            </h1>
            <p className="text-surface-400 mt-1">Manage your videos, credits, and settings.</p>
          </div>
          <Link
            href="/upload"
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-brand-600 to-accent-blue text-white font-semibold hover:opacity-90 transition-all glow-sm inline-flex items-center gap-2"
          >
            <FiVideo className="w-5 h-5" /> Upload Video
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Credits", value: user?.credits ?? 0, icon: FiCreditCard, color: "text-brand-400", bg: "bg-brand-500/10" },
            { label: "Storage Used", value: `${user?.storageUsed ?? 0} GB / 50 GB`, icon: FiHardDrive, color: "text-accent-blue", bg: "bg-accent-blue/10" },
            { label: "Videos Processed", value: "47", icon: FiBarChart2, color: "text-accent-green", bg: "bg-accent-green/10" },
            { label: "Queue", value: `${mockVideos.filter((v) => v.status === "queued" || v.status === "processing").length} active`, icon: FiCpu, color: "text-accent-amber", bg: "bg-accent-amber/10" },
          ].map((stat) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card p-4"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-8 h-8 rounded-lg ${stat.bg} flex items-center justify-center`}>
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                </div>
                <span className="text-xs text-surface-400 font-medium">{stat.label}</span>
              </div>
              <div className="text-lg font-bold">{stat.value}</div>
            </motion.div>
          ))}
        </div>

        {/* Storage Bar */}
        <div className="glass-card p-4 mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-surface-400">Storage</span>
            <span className="text-sm font-medium">{storagePercent.toFixed(0)}%</span>
          </div>
          <div className="h-2 bg-surface-700 rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-brand-500 to-accent-blue"
              initial={{ width: 0 }}
              animate={{ width: `${storagePercent}%` }}
              transition={{ duration: 1 }}
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-surface-800/50 rounded-xl p-1 w-fit">
          {(["queue", "history", "settings"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                activeTab === tab ? "bg-brand-500/20 text-brand-400" : "text-surface-400 hover:text-white"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Queue Tab */}
        {activeTab === "queue" && (
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-lg font-semibold">Processing Queue</h2>
              <div className="flex items-center gap-2">
                <button className="px-3 py-1.5 rounded-lg text-xs bg-surface-800 text-surface-300 hover:text-white transition-colors">
                  <FiPauseCircle className="w-4 h-4 inline mr-1" /> Pause All
                </button>
                <button className="px-3 py-1.5 rounded-lg text-xs bg-brand-500/20 text-brand-400 hover:text-brand-300 transition-colors">
                  <FiPlayCircle className="w-4 h-4 inline mr-1" /> Process All
                </button>
              </div>
            </div>

            {/* Search */}
            <input
              type="text"
              placeholder="Search videos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full sm:w-72 px-4 py-2.5 rounded-xl bg-surface-800 border border-white/5 text-sm placeholder:text-surface-500 focus:outline-none focus:border-brand-500/50 transition-colors"
            />

            <div className="space-y-2">
              {filteredVideos.map((video) => (
                <motion.div
                  key={video.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="glass-card p-4 flex flex-col sm:flex-row items-start sm:items-center gap-4"
                >
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    video.thumbnail === "green" ? "bg-accent-green/20" :
                    video.thumbnail === "blue" ? "bg-accent-blue/20" :
                    video.thumbnail === "red" ? "bg-accent-rose/20" :
                    "bg-surface-700"
                  }`}>
                    {video.status === "completed" ? <FiCheck className="w-5 h-5 text-accent-green" /> :
                     video.status === "failed" ? <FiX className="w-5 h-5 text-accent-rose" /> :
                     video.status === "processing" ? <FiCpu className="w-5 h-5 text-brand-400 animate-spin" /> :
                     <FiVideo className="w-5 h-5 text-surface-500" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{video.name}</p>
                    <p className="text-xs text-surface-500">{video.size} · {video.duration} · {video.uploaded}</p>
                  </div>

                  {video.status === "processing" && (
                    <div className="w-full sm:w-40 flex-shrink-0">
                      <div className="h-1.5 bg-surface-700 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full rounded-full bg-gradient-to-r from-brand-500 to-accent-blue"
                          animate={{ width: `${video.progress}%` }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                      <span className="text-xs text-surface-500 mt-0.5 block">{video.progress}%</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 flex-shrink-0">
                    {video.status === "completed" && (
                      <button className="px-3 py-1.5 rounded-lg text-xs bg-accent-green/20 text-accent-green hover:bg-accent-green/30 transition-colors">
                        <FiDownload className="w-3.5 h-3.5 inline mr-1" /> Download
                      </button>
                    )}
                    {video.status === "failed" && (
                      <button className="px-3 py-1.5 rounded-lg text-xs bg-accent-amber/20 text-accent-amber hover:bg-accent-amber/30 transition-colors">
                        <FiRefreshCw className="w-3.5 h-3.5 inline mr-1" /> Retry
                      </button>
                    )}
                    <button className="p-1.5 rounded-lg text-surface-500 hover:text-accent-rose transition-colors">
                      <FiTrash2 className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* History Tab */}
        {activeTab === "history" && (
          <div>
            <h2 className="text-lg font-semibold mb-4">Upload History</h2>
            <div className="space-y-2">
              {mockVideos.filter((v) => v.status === "completed").map((video) => (
                <div key={video.id} className="glass-card p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-accent-green/20 flex items-center justify-center">
                      <FiCheck className="w-5 h-5 text-accent-green" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{video.name}</p>
                      <p className="text-xs text-surface-500">{video.size} · Completed {video.uploaded}</p>
                    </div>
                  </div>
                  <button className="px-4 py-2 rounded-lg text-xs bg-brand-500/20 text-brand-400 hover:bg-brand-500/30 transition-colors">
                    <FiDownload className="w-4 h-4 inline mr-1" /> Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="text-lg font-semibold">Settings</h2>

            <div className="glass-card p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2"><FiUser className="w-5 h-5 text-brand-400" /> Profile</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-surface-400 block mb-1">Name</label>
                  <input type="text" defaultValue={user?.name} className="w-full px-4 py-2.5 rounded-xl bg-surface-800 border border-white/5 text-sm focus:outline-none focus:border-brand-500/50" />
                </div>
                <div>
                  <label className="text-sm text-surface-400 block mb-1">Email</label>
                  <input type="email" defaultValue={user?.email} className="w-full px-4 py-2.5 rounded-xl bg-surface-800 border border-white/5 text-sm focus:outline-none focus:border-brand-500/50" />
                </div>
              </div>
            </div>

            <div className="glass-card p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2"><FiKey className="w-5 h-5 text-brand-400" /> API Keys</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-lg bg-surface-800/50">
                  <div>
                    <p className="text-sm font-medium">Production Key</p>
                    <p className="text-xs text-surface-500 font-mono">vix_prod_••••••••••••7f3a</p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded bg-accent-green/20 text-accent-green">Active</span>
                </div>
                <button className="text-sm text-brand-400 hover:text-brand-300 transition-colors">
                  + Generate New Key
                </button>
              </div>
            </div>

            <div className="glass-card p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2"><FiBell className="w-5 h-5 text-brand-400" /> Notifications</h3>
              <div className="space-y-3">
                {["Processing complete", "Queue alerts", "Billing updates", "Security alerts"].map((n) => (
                  <label key={n} className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 rounded bg-surface-700 border-surface-600 text-brand-500" />
                    <span className="text-sm">{n}</span>
                  </label>
                ))}
              </div>
            </div>

            <button
              onClick={() => { logout(); setUser(null); }}
              className="px-4 py-2 rounded-lg text-sm bg-accent-rose/20 text-accent-rose hover:bg-accent-rose/30 transition-colors"
            >
              Sign Out
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
