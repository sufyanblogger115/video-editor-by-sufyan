export default function PrivacyPage() {
  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
        <div className="glass-card p-8 space-y-6 prose prose-invert max-w-none">
          <p className="text-surface-400">Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</p>

          <section>
            <h2 className="text-xl font-semibold mb-3">1. Information We Collect</h2>
            <p className="text-surface-300">We collect information you provide directly, including your name, email address, and uploaded video files. We also collect usage data to improve our services.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">2. How We Use Your Information</h2>
            <p className="text-surface-300">We use your information to process and edit your videos, improve our AI models, provide customer support, and send service-related communications.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">3. Data Storage</h2>
            <p className="text-surface-300">Your uploaded videos are processed securely and stored temporarily. Processed videos are available for download for 30 days before automatic deletion.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">4. Third-Party Services</h2>
            <p className="text-surface-300">We may use third-party services for hosting, analytics, and payment processing. These services have their own privacy policies.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">5. Your Rights</h2>
            <p className="text-surface-300">You have the right to access, correct, or delete your personal data at any time. Contact us at privacy@vidmorphx.com.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">6. Security</h2>
            <p className="text-surface-300">We use industry-standard encryption (TLS 1.3) and security measures to protect your data. All video processing occurs in isolated, secure environments.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">7. Contact</h2>
            <p className="text-surface-300">For privacy-related inquiries, contact us at privacy@vidmorphx.com or visit our <a href="/contact" className="text-brand-400 hover:underline">contact page</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
