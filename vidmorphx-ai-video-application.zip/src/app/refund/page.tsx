export default function RefundPage() {
  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold mb-8">Refund Policy</h1>
        <div className="glass-card p-8 space-y-6">
          <p className="text-surface-400">Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</p>

          <section>
            <h2 className="text-xl font-semibold mb-3">30-Day Money-Back Guarantee</h2>
            <p className="text-surface-300">We offer a full refund within 30 days of your initial purchase. If you&apos;re not satisfied with VidMorphX, contact us and we&apos;ll process your refund.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">How to Request a Refund</h2>
            <p className="text-surface-300">Email billing@vidmorphx.com with your account email and reason for refund. We typically process refunds within 3-5 business days.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Non-Refundable Items</h2>
            <ul className="text-surface-300 space-y-2 list-disc list-inside">
              <li>Individual credit packs purchased separately</li>
              <li>Refund requests after the 30-day window</li>
              <li>Accounts terminated for terms violations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Contact</h2>
            <p className="text-surface-300">For refund inquiries, email billing@vidmorphx.com or visit our <a href="/contact" className="text-brand-400 hover:underline">contact page</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
