export default function TermsPage() {
  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
        <div className="glass-card p-8 space-y-6">
          <p className="text-surface-400">Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</p>

          <section>
            <h2 className="text-xl font-semibold mb-3">1. Acceptance of Terms</h2>
            <p className="text-surface-300">By accessing or using VidMorphX, you agree to be bound by these Terms of Service. If you do not agree, do not use our services.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">2. Account</h2>
            <p className="text-surface-300">You are responsible for maintaining the security of your account. You must be at least 16 years old to create an account.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">3. Usage</h2>
            <p className="text-surface-300">You may only upload content you have the right to process. You agree not to upload illegal, harmful, or offensive content. We reserve the right to terminate accounts that violate these terms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">4. Credits</h2>
            <p className="text-surface-300">Credits reset monthly according to your plan. Unused credits do not roll over. Credits are non-transferable and non-refundable.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">5. Intellectual Property</h2>
            <p className="text-surface-300">You retain full ownership of your uploaded and processed videos. VidMorphX does not claim any rights to your content.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">6. Limitation of Liability</h2>
            <p className="text-surface-300">VidMorphX is provided "as is." We do not guarantee uninterrupted service and are not liable for any damages arising from the use of our platform.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">7. Changes</h2>
            <p className="text-surface-300">We may update these terms at any time. Continued use of the service constitutes acceptance of modified terms.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
