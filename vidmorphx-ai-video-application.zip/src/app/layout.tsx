import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/header";
import Footer from "@/footer";
import Providers from "@/providers";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "VidMorphX — AI-Powered Video Editing Platform",
  description: "Upload videos and let AI automatically detect scenes, remove silence, apply effects, generate subtitles, and export in any format. No editing skills needed.",
  keywords: ["AI video editing", "automatic video editor", "video processing", "AI effects", "subtitle generation", "video enhancement"],
  authors: [{ name: "VidMorphX" }],
  openGraph: {
    title: "VidMorphX — AI-Powered Video Editing Platform",
    description: "Upload videos and let AI automatically edit, enhance, and export professional videos.",
    type: "website",
    url: "https://vidmorphx.com",
    siteName: "VidMorphX",
  },
  twitter: {
    card: "summary_large_image",
    title: "VidMorphX — AI-Powered Video Editing Platform",
    description: "Upload videos and let AI automatically edit, enhance, and export professional videos.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
    },
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="bg-surface-950 text-surface-100 antialiased min-h-screen flex flex-col">
        <Providers>
          <Header />
          <main className="flex-1 pt-16">{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
