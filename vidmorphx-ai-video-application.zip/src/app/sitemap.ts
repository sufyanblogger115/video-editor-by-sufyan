export default function sitemap() {
  const baseUrl = "https://vidmorphx.com";
  const routes = [
    "",
    "/dashboard",
    "/upload",
    "/pricing",
    "/about",
    "/contact",
    "/privacy",
    "/terms",
    "/cookies",
    "/refund",
  ];

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" ? "daily" : "weekly" as const,
    priority: route === "" ? 1 : route === "/upload" ? 0.9 : 0.7,
  }));
}
