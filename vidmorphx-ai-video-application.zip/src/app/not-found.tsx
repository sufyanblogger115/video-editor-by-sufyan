import Link from "next/link";
import { FiAlertTriangle, FiArrowLeft } from "react-icons/fi";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center">
        <div className="w-24 h-24 rounded-full bg-accent-rose/20 flex items-center justify-center mx-auto mb-6">
          <FiAlertTriangle className="w-12 h-12 text-accent-rose" />
        </div>
        <h1 className="text-6xl font-bold gradient-text mb-2">404</h1>
        <p className="text-xl text-surface-400 mb-8">Page not found</p>
        <Link
          href="/"
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-brand-600 to-accent-blue text-white font-semibold hover:opacity-90 transition-all inline-flex items-center gap-2"
        >
          <FiArrowLeft className="w-5 h-5" /> Back to Home
        </Link>
      </div>
    </div>
  );
}
