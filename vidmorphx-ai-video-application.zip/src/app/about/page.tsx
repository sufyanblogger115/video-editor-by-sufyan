import { FiCpu, FiShield, FiGlobe, FiHeart, FiAward, FiUsers } from "react-icons/fi";

export default function AboutPage() {
  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            About <span className="gradient-text">VidMorphX</span>
          </h1>
          <p className="text-lg text-surface-400 max-w-2xl mx-auto">
            We&apos;re on a mission to make professional video editing accessible to everyone.
          </p>
        </div>

        {/* Mission */}
        <div className="glass-card p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
          <p className="text-surface-300 leading-relaxed">
            VidMorphX was born from a simple belief: great video editing shouldn&apos;t require years of experience or expensive software. Our AI-powered platform automates the entire editing pipeline — from scene detection and smart cuts to color grading and subtitle generation — so you can focus on creating content, not wrestling with timelines.
          </p>
        </div>

        {/* Values */}
        <h2 className="text-2xl font-bold mb-6">Our Values</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {[
            { icon: FiCpu, title: "AI-First", desc: "We leverage cutting-edge AI to automate complex editing tasks." },
            { icon: FiShield, title: "Privacy", desc: "Your videos are encrypted and never shared with third parties." },
            { icon: FiGlobe, title: "Accessibility", desc: "Professional editing tools for creators worldwide." },
            { icon: FiHeart, title: "Creator-Focused", desc: "Built by creators, for creators. Every feature solves a real problem." },
            { icon: FiAward, title: "Quality", desc: "We&apos;re obsessed with output quality — every pixel, every frame." },
            { icon: FiUsers, title: "Community", desc: "500K+ creators trust VidMorphX daily." },
          ].map((value) => (
            <div key={value.title} className="glass-card p-6">
              <value.icon className="w-8 h-8 text-brand-400 mb-3" />
              <h3 className="font-semibold mb-2">{value.title}</h3>
              <p className="text-sm text-surface-400">{value.desc}</p>
            </div>
          ))}
        </div>

        {/* Careers */}
        <div className="glass-card p-8">
          <h2 className="text-2xl font-bold mb-4">Careers</h2>
          <p className="text-surface-300 mb-6">
            We&apos;re always looking for talented people to join our team. If you&apos;re passionate about AI and video technology, we&apos;d love to hear from you.
          </p>
          <div className="space-y-3">
            {[
              { title: "Senior ML Engineer", location: "Remote", type: "Full-time" },
              { title: "Frontend Engineer", location: "Remote", type: "Full-time" },
              { title: "Product Designer", location: "San Francisco / Remote", type: "Full-time" },
            ].map((job) => (
              <div key={job.title} className="flex items-center justify-between p-4 rounded-xl bg-surface-800/50">
                <div>
                  <p className="font-medium">{job.title}</p>
                  <p className="text-sm text-surface-500">{job.location} · {job.type}</p>
                </div>
                <a href="/contact" className="text-sm text-brand-400 hover:text-brand-300">Apply →</a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
