"use client";

import { useState } from "react";
import { FiSend, FiCheck, FiMail, FiUser, FiMessageSquare } from "react-icons/fi";

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen pt-8 flex items-center justify-center">
        <div className="max-w-lg mx-auto px-4 text-center">
          <div className="glass-card p-12">
            <div className="w-16 h-16 rounded-full bg-accent-green/20 flex items-center justify-center mx-auto mb-6">
              <FiCheck className="w-8 h-8 text-accent-green" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Message Sent!</h1>
            <p className="text-surface-400 mb-6">Thanks for reaching out. We&apos;ll get back to you within 24 hours.</p>
            <button
              onClick={() => setSubmitted(false)}
              className="px-6 py-3 rounded-xl bg-brand-500/20 text-brand-400 font-medium hover:bg-brand-500/30 transition-colors"
            >
              Send Another
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            Get in <span className="gradient-text">Touch</span>
          </h1>
          <p className="text-surface-400 max-w-xl mx-auto">
            Have a question, feature request, or just want to say hello? We&apos;d love to hear from you.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="space-y-4">
            {[
              { icon: FiMail, label: "Email", value: "hello@vidmorphx.com" },
              { icon: FiMessageSquare, label: "Support", value: "support@vidmorphx.com" },
              { icon: FiUser, label: "Sales", value: "sales@vidmorphx.com" },
            ].map((item) => (
              <div key={item.label} className="glass-card p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center">
                  <item.icon className="w-5 h-5 text-brand-400" />
                </div>
                <div>
                  <p className="text-xs text-surface-500">{item.label}</p>
                  <p className="text-sm font-medium">{item.value}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="md:col-span-2 glass-card p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-surface-400 block mb-1" htmlFor="name">Name</label>
                <input
                  id="name"
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-surface-800 border border-white/5 text-sm placeholder:text-surface-500 focus:outline-none focus:border-brand-500/50 transition-colors"
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className="text-sm text-surface-400 block mb-1" htmlFor="email">Email</label>
                <input
                  id="email"
                  required
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-surface-800 border border-white/5 text-sm placeholder:text-surface-500 focus:outline-none focus:border-brand-500/50 transition-colors"
                  placeholder="you@example.com"
                />
              </div>
            </div>
            <div>
              <label className="text-sm text-surface-400 block mb-1" htmlFor="subject">Subject</label>
              <input
                id="subject"
                required
                type="text"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-surface-800 border border-white/5 text-sm placeholder:text-surface-500 focus:outline-none focus:border-brand-500/50 transition-colors"
                placeholder="How can we help?"
              />
            </div>
            <div>
              <label className="text-sm text-surface-400 block mb-1" htmlFor="message">Message</label>
              <textarea
                id="message"
                required
                rows={5}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-surface-800 border border-white/5 text-sm placeholder:text-surface-500 focus:outline-none focus:border-brand-500/50 transition-colors resize-none"
                placeholder="Tell us more..."
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-brand-600 to-accent-blue text-white font-semibold hover:opacity-90 transition-all glow-sm flex items-center justify-center gap-2"
            >
              <FiSend className="w-5 h-5" /> Send Message
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
