"use client";

import { useStore } from "@/store";
import { useState, useEffect } from "react";
import {
  FiUploadCloud, FiVideo, FiSettings, FiCheck, FiX,
  FiDownload, FiClock, FiZap, FiAperture, FiMusic,
  FiGlobe, FiImage, FiFilm, FiScissors
} from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";
import UploadZone from "@/uploadzone";

const EXPORT_QUALITIES = ["720p", "1080p", "1440p", "4K"];
const EXPORT_FORMATS = ["MP4", "MOV", "WebM"];

export default function UploadPage() {
  const { user, setUser, isLoggedIn } = useStore();
  const [quality, setQuality] = useState("1080p");
  const [format, setFormat] = useState("MP4");
  const [effects, setEffects] = useState<Record<string, boolean>>({
    smartCuts: true,
    silenceRemoval: true,
    subtitles: true,
    colorGrading: true,
    stabilization: true,
    noiseRemoval: true,
    faceTracking: true,
    transitions: true,
  });

  useEffect(() => {
    if (!isLoggedIn) {
      setUser({ id: 1, name: "Alex Morgan", email: "alex@example.com", credits: 25, storageUsed: "4.2" });
    }
  }, [isLoggedIn, setUser]);

  const toggleEffect = (key: string) => {
    setEffects((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const effectList = [
    { key: "smartCuts", label: "Smart Cuts", icon: FiScissors, desc: "Auto-trim scenes" },
    { key: "silenceRemoval", label: "Silence Removal", icon: FiMusic, desc: "Remove dead air" },
    { key: "subtitles", label: "Auto Subtitles", icon: FiGlobe, desc: "Generate captions" },
    { key: "colorGrading", label: "Color Grading", icon: FiImage, desc: "Cinematic LUTs" },
    { key: "stabilization", label: "Stabilization", icon: FiAperture, desc: "Smooth footage" },
    { key: "noiseRemoval", label: "Noise Removal", icon: FiMusic, desc: "Clean audio" },
    { key: "faceTracking", label: "Face Tracking", icon: FiFilm, desc: "Smart crop" },
    { key: "transitions", label: "Transitions", icon: FiZap, desc: "Auto transitions" },
  ];

  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">
            Upload & <span className="gradient-text">Edit</span>
          </h1>
          <p className="text-surface-400 mt-1">Upload your videos and configure AI editing options.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Upload Area */}
          <div className="lg:col-span-2">
            <div className="glass-card p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <FiUploadCloud className="w-5 h-5 text-brand-400" />
                Upload Videos
              </h2>
              <UploadZone />
            </div>

            {/* Export Settings */}
            <div className="glass-card p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <FiSettings className="w-5 h-5 text-brand-400" />
                Export Settings
              </h2>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-surface-400 block mb-2">Quality</label>
                  <div className="flex gap-2">
                    {EXPORT_QUALITIES.map((q) => (
                      <button
                        key={q}
                        onClick={() => setQuality(q)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                          quality === q
                            ? "bg-brand-500/20 text-brand-400 border border-brand-500/30"
                            : "bg-surface-800 text-surface-400 hover:text-white border border-transparent"
                        }`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-sm text-surface-400 block mb-2">Format</label>
                  <div className="flex gap-2">
                    {EXPORT_FORMATS.map((f) => (
                      <button
                        key={f}
                        onClick={() => setFormat(f)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                          format === f
                            ? "bg-brand-500/20 text-brand-400 border border-brand-500/30"
                            : "bg-surface-800 text-surface-400 hover:text-white border border-transparent"
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 rounded-xl bg-surface-800/50">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-surface-400">Credits required per video</span>
                  <span className="font-semibold">{quality === "4K" ? 5 : quality === "1440p" ? 3 : 2}</span>
                </div>
                <div className="flex items-center justify-between text-sm mt-2">
                  <span className="text-surface-400">Your credits</span>
                  <span className="font-semibold gradient-text">{user?.credits ?? 0}</span>
                </div>
              </div>
            </div>
          </div>

          {/* AI Effects Panel */}
          <div>
            <div className="glass-card p-6 sticky top-24">
              <h2 className="text-lg font-semibold mb-4">
                AI Effects
              </h2>
              <p className="text-xs text-surface-500 mb-4">Toggle effects to apply to your videos.</p>

              <div className="space-y-3">
                {effectList.map((effect) => (
                  <button
                    key={effect.key}
                    onClick={() => toggleEffect(effect.key)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${
                      effects[effect.key]
                        ? "bg-brand-500/10 border border-brand-500/30"
                        : "bg-surface-800/50 border border-transparent hover:border-white/10"
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      effects[effect.key] ? "bg-brand-500/20" : "bg-surface-700"
                    }`}>
                      <effect.icon className={`w-4 h-4 ${effects[effect.key] ? "text-brand-400" : "text-surface-500"}`} />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{effect.label}</p>
                      <p className="text-xs text-surface-500">{effect.desc}</p>
                    </div>
                    <div className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                      effects[effect.key] ? "bg-brand-500 border-brand-500" : "border-surface-600"
                    }`}>
                      {effects[effect.key] && <FiCheck className="w-3 h-3 text-white" />}
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-6 pt-4 border-t border-white/5">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-surface-400">Effects active</span>
                  <span className="font-semibold">{Object.values(effects).filter(Boolean).length} / {effectList.length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
