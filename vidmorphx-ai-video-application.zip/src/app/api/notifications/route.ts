import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json({ notifications: [] });
    }

    const notifs = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, parseInt(userId)))
      .orderBy(desc(notifications.createdAt))
      .limit(20);

    return NextResponse.json({ notifications: notifs });
  } catch {
    return NextResponse.json({ notifications: [] });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, type, title, message } = body;

    if (!userId || !type || !title || !message) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    const [notif] = await db
      .insert(notifications)
      .values({ userId: parseInt(userId), type, title, message })
      .returning();

    return NextResponse.json({ notification: notif }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
