import { NextResponse } from "next/server";
import { db } from "@/db";
import { videos, users } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json({ error: "userId required" }, { status: 400 });
    }

    const userVideos = await db
      .select()
      .from(videos)
      .where(eq(videos.userId, parseInt(userId)))
      .orderBy(desc(videos.createdAt));

    return NextResponse.json({ videos: userVideos });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, originalName, fileName, fileSize, mimeType, effects, exportQuality, exportFormat } = body;

    if (!userId || !originalName || !fileName) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const [video] = await db
      .insert(videos)
      .values({
        userId: parseInt(userId),
        originalName,
        fileName,
        fileSize: fileSize?.toString() || "0",
        mimeType,
        effects,
        exportQuality: exportQuality || "1080p",
        exportFormat: exportFormat || "mp4",
        status: "queued",
        queuePosition: 1,
      })
      .returning();

    return NextResponse.json({ video }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
