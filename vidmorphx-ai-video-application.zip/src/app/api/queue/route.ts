import { NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    const queue = await db
      .select()
      .from(videos)
      .where(
        eq(videos.userId, userId ? parseInt(userId) : 0)
      );

    return NextResponse.json({ queue });
  } catch {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, videoId } = body;

    if (action === "pause") {
      await db
        .update(videos)
        .set({ status: "queued", stage: "Paused" })
        .where(eq(videos.id, videoId ? parseInt(videoId) : -1));
    } else if (action === "resume") {
      await db
        .update(videos)
        .set({ status: "queued", stage: "Resumed" })
        .where(eq(videos.id, videoId ? parseInt(videoId) : -1));
    } else if (action === "clear") {
      await db
        .delete(videos)
        .where(eq(videos.id, videoId ? parseInt(videoId) : -1));
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
