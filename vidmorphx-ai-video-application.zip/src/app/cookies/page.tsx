export default function CookiesPage() {
  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold mb-8">Cookie Policy</h1>
        <div className="glass-card p-8 space-y-6">
          <p className="text-surface-400">Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</p>

          <section>
            <h2 className="text-xl font-semibold mb-3">1. What Are Cookies</h2>
            <p className="text-surface-300">Cookies are small text files stored on your device when you visit our website. They help us provide a better experience and understand how you use our services.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">2. Types of Cookies We Use</h2>
            <ul className="text-surface-300 space-y-2 list-disc list-inside">
              <li><strong>Essential cookies:</strong> Required for basic site functionality (authentication, session management).</li>
              <li><strong>Analytics cookies:</strong> Help us understand how visitors interact with our site.</li>
              <li><strong>Preference cookies:</strong> Remember your settings and preferences.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">3. Managing Cookies</h2>
            <p className="text-surface-300">You can control cookies through your browser settings. Disabling essential cookies may affect site functionality.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">4. Third-Party Cookies</h2>
            <p className="text-surface-300">We may use third-party analytics services that set their own cookies. These are governed by their respective privacy policies.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
