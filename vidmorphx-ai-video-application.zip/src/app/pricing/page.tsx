import Link from "next/link";
import { FiCheck, FiStar, FiAward as FiCrown, FiZap, FiShield } from "react-icons/fi";

const plans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "Perfect for getting started",
    features: ["10 credits/month", "720p export", "Basic AI effects", "5 videos/month", "Community support"],
    cta: "Get Started",
    href: "/upload",
    highlighted: false,
    icon: FiStar,
  },
  {
    name: "Pro",
    price: "$29",
    period: "/month",
    description: "For serious creators",
    features: ["200 credits/month", "4K export", "All AI effects", "Unlimited videos", "Priority support", "Auto subtitles", "API access"],
    cta: "Start Pro Trial",
    href: "/upload",
    highlighted: true,
    icon: FiZap,
    badge: "Most Popular",
  },
  {
    name: "Enterprise",
    price: "$99",
    period: "/month",
    description: "For teams and businesses",
    features: ["Unlimited credits", "4K+ export", "All AI effects", "Unlimited videos", "Dedicated support", "Custom branding", "Team management", "SLA guarantee", "Advanced API"],
    cta: "Contact Sales",
    href: "/contact",
    highlighted: false,
    icon: FiCrown,
  },
];

export default function PricingPage() {
  return (
    <div className="min-h-screen pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <span className="text-sm font-bold text-brand-400 uppercase tracking-wider">Pricing</span>
          <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-4">
            Simple, <span className="gradient-text">Transparent</span> Pricing
          </h1>
          <p className="text-surface-400 max-w-2xl mx-auto">
            Start free, upgrade when you need more. No hidden fees, cancel anytime.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`glass-card p-8 relative transition-all duration-300 hover:border-brand-500/30 ${
                plan.highlighted ? "border-brand-500/30 glow" : ""
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-brand-500 to-accent-blue text-xs font-bold text-white">
                  {plan.badge}
                </div>
              )}
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  plan.highlighted ? "bg-brand-500/20" : "bg-surface-800"
                }`}>
                  <plan.icon className={`w-5 h-5 ${plan.highlighted ? "text-brand-400" : "text-surface-400"}`} />
                </div>
                <h3 className="text-xl font-bold">{plan.name}</h3>
              </div>

              <div className="mb-6">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className="text-surface-400 text-sm ml-1">{plan.period}</span>
              </div>

              <p className="text-sm text-surface-400 mb-6">{plan.description}</p>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm">
                    <FiCheck className="w-4 h-4 text-accent-green flex-shrink-0" />
                    <span className="text-surface-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link
                href={plan.href}
                className={`w-full py-3 rounded-xl font-semibold text-center block transition-all ${
                  plan.highlighted
                    ? "bg-gradient-to-r from-brand-600 to-accent-blue text-white hover:opacity-90 glow-sm"
                    : "border border-white/10 text-white hover:bg-white/5"
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>

        {/* FAQ */}
        <div className="max-w-2xl mx-auto mt-20">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              { q: "What happens when I run out of credits?", a: "You can upgrade your plan or wait until next month when your credits renew." },
              { q: "Can I cancel anytime?", a: "Yes, cancel at any time. You'll keep access until the end of your billing period." },
              { q: "Do you offer refunds?", a: "Yes, we offer a 30-day money-back guarantee. See our refund policy for details." },
              { q: "What formats do you support?", a: "We support MP4, MOV, WebM, and MKV for input, and export to MP4, MOV, and WebM." },
              { q: "Is there an API?", a: "Yes, Pro and Enterprise plans include API access with full documentation." },
            ].map((faq) => (
              <div key={faq.q} className="glass-card p-5">
                <h3 className="font-semibold mb-2">{faq.q}</h3>
                <p className="text-sm text-surface-400">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
