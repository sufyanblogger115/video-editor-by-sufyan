import { pgTable, serial, text, timestamp, integer, boolean, varchar, numeric, jsonb } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name"),
  email: varchar("email", { length: 255 }).unique().notNull(),
  password: text("password"),
  avatar: text("avatar"),
  provider: varchar("provider", { length: 50 }),
  credits: integer("credits").default(10),
  storageUsed: numeric("storage_used", { precision: 10, scale: 2 }).default("0"),
  role: varchar("role", { length: 20 }).default("user"),
  emailVerified: boolean("email_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  originalName: text("original_name").notNull(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  fileSize: numeric("file_size", { precision: 15, scale: 2 }).default("0"),
  mimeType: varchar("mime_type", { length: 100 }),
  duration: numeric("duration", { precision: 8, scale: 2 }),
  thumbnail: text("thumbnail"),
  outputUrl: text("output_url"),
  status: varchar("status", { length: 20 }).default("queued"),
  progress: integer("progress").default(0),
  stage: varchar("stage", { length: 50 }).default("waiting"),
  queuePosition: integer("queue_position").default(0),
  estimatedTime: varchar("estimated_time", { length: 50 }),
  exportQuality: varchar("export_quality", { length: 20 }).default("1080p"),
  exportFormat: varchar("export_format", { length: 10 }).default("mp4"),
  effects: jsonb("effects"),
  errorMessage: text("error_message"),
  retryCount: integer("retry_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const processingJobs = pgTable("processing_jobs", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id),
  jobType: varchar("job_type", { length: 50 }).notNull(),
  status: varchar("status", { length: 20 }).default("pending"),
  result: jsonb("result"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: varchar("type", { length: 50 }).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  key: varchar("key", { length: 255 }).notNull(),
  name: text("name").notNull(),
  active: boolean("active").default(true),
  lastUsed: timestamp("last_used"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Video = typeof videos.$inferSelect;
export type ProcessingJob = typeof processingJobs.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type ApiKey = typeof apiKeys.$inferSelect;
