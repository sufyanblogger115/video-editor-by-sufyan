import { FiStar } from "react-icons/fi";

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Content Creator",
    content: "VidMorphX completely changed my workflow. I went from spending hours editing to just uploading and downloading. The AI does an incredible job.",
    rating: 5,
    avatar: "SC",
  },
  {
    name: "Marcus Johnson",
    role: "Marketing Director",
    content: "We use VidMorphX for all our product videos. The auto-subtitles and color grading save our team 10+ hours per week.",
    rating: 5,
    avatar: "MJ",
  },
  {
    name: "Aiko Tanaka",
    role: "YouTuber",
    content: "The silence removal and smart cuts are game-changing. My videos look professionally edited without me lifting a finger.",
    rating: 5,
    avatar: "AT",
  },
  {
    name: "David Park",
    role: "Freelance Filmmaker",
    content: "I was skeptical at first, but the quality of AI processing is genuinely impressive. The 4K export is crystal clear.",
    rating: 5,
    avatar: "DP",
  },
];

export default function Testimonials() {
  return (
    <section className="py-20 bg-surface-900/30" aria-label="Testimonials">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-sm font-bold text-brand-400 uppercase tracking-wider">Testimonials</span>
          <h2 className="text-3xl sm:text-4xl font-bold mt-2 mb-4">
            Loved by <span className="gradient-text">Creators</span>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t) => (
            <div key={t.name} className="glass-card p-6 hover:border-brand-500/30 transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <FiStar key={i} className="w-4 h-4 text-accent-amber fill-accent-amber" />
                ))}
              </div>
              <p className="text-sm text-surface-300 mb-4 leading-relaxed">&ldquo;{t.content}&rdquo;</p>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-500 to-accent-blue flex items-center justify-center text-xs font-bold">
                  {t.avatar}
                </div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-surface-500">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
