"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { FiPlay, FiZap, FiArrowRight } from "react-icons/fi";
import { FaBolt } from "react-icons/fa6";
import UploadZone from "@/uploadzone";

const SparkleIcon = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
);

export default function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden" aria-label="Hero">
      {/* Background gradients */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-blue/15 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: "1.5s" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-500/5 rounded-full blur-3xl" />
      </div>

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)", backgroundSize: "60px 60px" }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 md:py-40">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-500/10 border border-brand-500/20 mb-6"
            >
              <FaBolt className="w-4 h-4 text-brand-400" />
              <span className="text-sm font-medium text-brand-300">AI-Powered Video Editing</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6"
            >
              Edit Videos with{" "}
              <span className="gradient-text">AI Magic</span>
              <br />
              <span className="text-surface-300">Zero Skills Required</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-surface-400 mb-8 max-w-lg"
            >
              Upload your videos and let our AI automatically detect scenes, remove silence, apply cinematic effects, generate subtitles, and export professional results.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Link
                href="/upload"
                className="px-8 py-4 rounded-xl bg-gradient-to-r from-brand-600 to-accent-blue text-white font-semibold hover:opacity-90 transition-all glow-sm inline-flex items-center justify-center gap-2 text-lg"
              >
                <FiPlay className="w-5 h-5" /> Start Editing Free
              </Link>
              <Link
                href="/dashboard"
                className="px-8 py-4 rounded-xl border border-white/10 text-white font-semibold hover:bg-white/5 transition-all inline-flex items-center justify-center gap-2 text-lg"
              >
                See Dashboard <FiArrowRight className="w-5 h-5" />
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex items-center gap-6 mt-8 text-sm text-surface-400"
            >
              <div className="flex items-center gap-2">
                <SparkleIcon /> <span className="text-accent-green">Free 10 credits</span>
              </div>
              <div className="flex items-center gap-2">
                <SparkleIcon /> <span className="text-accent-green">No signup needed</span>
              </div>
              <div className="flex items-center gap-2">
                <SparkleIcon /> <span className="text-accent-green">4K export</span>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="glass-card p-2 glow">
              <div className="rounded-2xl overflow-hidden bg-surface-900 aspect-video flex items-center justify-center relative">
                <div className="absolute inset-0 bg-gradient-to-br from-brand-600/20 to-accent-blue/20" />
                <div className="relative text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-brand-500 to-accent-blue flex items-center justify-center mx-auto mb-4 shadow-lg shadow-brand-500/25">
                    <FiPlay className="w-8 h-8 text-white ml-1" />
                  </div>
                  <p className="text-surface-300 font-medium">Upload a video to preview</p>
                  <p className="text-surface-500 text-sm mt-1">MP4, MOV, WebM supported</p>
                </div>
              </div>
            </div>
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 glass-card px-4 py-2 animate-float text-sm">
              <span className="text-accent-green font-semibold">AI Processing</span>
            </div>
            <div className="absolute -bottom-4 -left-4 glass-card px-4 py-2 animate-float-delayed text-sm">
              <span className="text-brand-400 font-semibold">4K Export</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scrolling logos */}
      <div className="relative border-y border-white/5 bg-surface-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-sm text-surface-500 mb-6">Trusted by creators on</p>
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12 opacity-40">
            {["YouTube", "TikTok", "Instagram", "Twitch", "Twitter", "LinkedIn"].map((brand) => (
              <span key={brand} className="text-lg font-bold text-surface-300">{brand}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Quick upload */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="glass-card p-6 md:p-8 glow-sm">
          <UploadZone />
        </div>
      </div>
    </section>
  );
}
