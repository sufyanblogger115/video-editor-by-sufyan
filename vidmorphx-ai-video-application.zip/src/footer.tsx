import Link from "next/link";
import { FiTwitter, FiLinkedin, FiGithub } from "react-icons/fi";
import { FaDiscord } from "react-icons/fa6";

const footerCols = [
  {
    title: "Company",
    links: [
      { href: "/about", label: "About" },
      { href: "/contact", label: "Contact" },
      { href: "/about", label: "Careers" },
    ],
  },
  {
    title: "Legal",
    links: [
      { href: "/privacy", label: "Privacy Policy" },
      { href: "/terms", label: "Terms of Service" },
      { href: "/cookies", label: "Cookie Policy" },
      { href: "/refund", label: "Refund Policy" },
    ],
  },
  {
    title: "Resources",
    links: [
      { href: "/about", label: "Help Center" },
      { href: "/about", label: "FAQ" },
      { href: "/about", label: "API Docs" },
    ],
  },
  {
    title: "Social",
    links: [
      { href: "https://twitter.com", label: "Twitter", icon: FiTwitter },
      { href: "https://linkedin.com", label: "LinkedIn", icon: FiLinkedin },
      { href: "https://discord.com", label: "Discord", icon: FaDiscord },
      { href: "https://github.com", label: "GitHub", icon: FiGithub },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/5 mt-20" role="contentinfo">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {footerCols.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-white mb-4">{col.title}</h3>
              <ul className="space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-surface-400 hover:text-brand-400 transition-colors flex items-center gap-2"
                    >
                      {'icon' in link && link.icon && <link.icon className="w-4 h-4" />}
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-500 to-accent-blue flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <span className="text-sm font-bold gradient-text">VidMorphX</span>
          </div>
          <p className="text-sm text-surface-500">&copy; {new Date().getFullYear()} VidMorphX. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
