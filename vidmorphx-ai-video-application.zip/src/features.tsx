import {
  FiScissors, FiMic, FiVideo, FiMusic, FiImage, FiZap,
  FiGlobe, FiShield, FiCpu, FiClock, FiLayers, FiAperture,
  FiFilm, FiDownload, FiSettings
} from "react-icons/fi";
import { FaRobot, FaComments, FaBolt } from "react-icons/fa6";

const featureCategories = [
  {
    title: "AI Detection",
    icon: FiCpu,
    features: [
      "Scene Detection", "Faces", "Objects", "Speech", "Music",
      "Silence", "Motion", "Lighting", "Landscape", "Animals", "People",
    ],
  },
  {
    title: "Smart Editing",
    icon: FiScissors,
    features: [
      "Smart Cuts", "Auto Trim", "Silence Removal", "Face Tracking",
      "Auto Zoom", "Motion Tracking", "Auto Crop", "Smart Reframing",
    ],
  },
  {
    title: "Visual Effects",
    icon: FiImage,
    features: [
      "Color Correction", "Color Grading", "Exposure Fix", "HDR Enhancement",
      "Sharpen", "Denoise", "Stabilization", "Frame Interpolation", "Film Grain", "Vignette",
    ],
  },
  {
    title: "Speed & Transitions",
    icon: FiZap,
    features: [
      "Speed Ramp", "Slow Motion", "Fast Motion", "Fade", "Flash",
      "Glitch", "Blur", "Spin", "Whip", "Slide",
    ],
  },
  {
    title: "Audio & Subtitles",
    icon: FiMusic,
    features: [
      "Noise Removal", "Auto Subtitles", "Animated Captions",
      "Subtitle Translation", "Voice Enhancement", "Auto Music Replacement",
      "Volume Normalization",
    ],
  },
  {
    title: "Format & Export",
    icon: FiDownload,
    features: [
      "Vertical / Square Conversion", "Shorts Creation", "Reels Format",
      "TikTok Format", "720p/1080p/1440p/4K", "MP4/MOV/WebM",
    ],
  },
];

export default function FeatureGrid() {
  return (
    <section className="py-20" aria-label="Features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-sm font-bold text-brand-400 uppercase tracking-wider">Features</span>
          <h2 className="text-3xl sm:text-4xl font-bold mt-2 mb-4">
            Everything You Need, <span className="gradient-text">Automated</span>
          </h2>
          <p className="text-surface-400 max-w-2xl mx-auto">
            From raw footage to polished masterpiece — all handled by AI in minutes.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featureCategories.map((category) => (
            <div key={category.title} className="glass-card p-6 hover:border-brand-500/30 transition-all duration-300 group">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center group-hover:bg-brand-500/20 transition-colors">
                  <category.icon className="w-5 h-5 text-brand-400" />
                </div>
                <h3 className="font-bold">{category.title}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {category.features.map((feat) => (
                  <span
                    key={feat}
                    className="px-3 py-1 rounded-full bg-surface-800 text-xs text-surface-300 border border-white/5"
                  >
                    {feat}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
