"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { FiMenu, FiX, FiUser, FiCpu, FiChevronDown } from "react-icons/fi";
import { useState, useCallback } from "react";
import { useStore } from "@/store";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/dashboard", label: "Dashboard" },
  { href: "/upload", label: "Upload" },
  { href: "/pricing", label: "Pricing" },
];

export default function Header() {
  const pathname = usePathname();
  const { isLoggedIn, user, logout } = useStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const closeMobile = useCallback(() => setMobileOpen(false), []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 glass"
      role="banner"
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between" aria-label="Main navigation">
        <Link href="/" className="flex items-center gap-2 group" aria-label="VidMorphX Home">
          <motion.div
            className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-accent-blue flex items-center justify-center"
            whileHover={{ scale: 1.05, rotate: 5 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <FiCpu className="w-5 h-5 text-white" />
          </motion.div>
          <span className="text-xl font-bold gradient-text">VidMorphX</span>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                pathname === link.href
                  ? "text-brand-400 bg-brand-500/10"
                  : "text-surface-300 hover:text-white hover:bg-white/5"
              }`}
              aria-current={pathname === link.href ? "page" : undefined}
            >
              {link.label}
            </Link>
          ))}
          <Link href="/about" className="px-4 py-2 rounded-lg text-sm font-medium text-surface-300 hover:text-white hover:bg-white/5 transition-all duration-200">
            About
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-3">
          {isLoggedIn ? (
            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all text-sm"
                aria-expanded={profileOpen}
                aria-haspopup="true"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-brand-500 to-accent-blue flex items-center justify-center text-xs font-bold">
                  {user?.name?.[0]?.toUpperCase() || "U"}
                </div>
                <span className="text-surface-300">{user?.name || "User"}</span>
                <FiChevronDown className={`w-4 h-4 text-surface-400 transition-transform ${profileOpen ? "rotate-180" : ""}`} />
              </button>
              {profileOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute right-0 top-full mt-2 w-56 glass-card p-2"
                >
                  <Link href="/dashboard" className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-surface-300 hover:bg-white/5 hover:text-white transition-all">
                    <FiUser className="w-4 h-4" /> Dashboard
                  </Link>
                  <button
                    onClick={() => { logout(); setProfileOpen(false); }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-accent-rose hover:bg-accent-rose/10 transition-all"
                  >
                    Sign Out
                  </button>
                </motion.div>
              )}
            </div>
          ) : (
            <Link
              href="/dashboard"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-brand-600 to-accent-blue text-white text-sm font-semibold hover:opacity-90 transition-all glow-sm"
            >
              Sign In
            </Link>
          )}
        </div>

        <button
          className="md:hidden p-2 text-surface-300 hover:text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? <FiX className="w-6 h-6" /> : <FiMenu className="w-6 h-6" />}
        </button>
      </nav>

      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden glass border-t border-white/5"
        >
          <div className="px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={closeMobile}
                className={`block px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  pathname === link.href
                    ? "text-brand-400 bg-brand-500/10"
                    : "text-surface-300 hover:text-white hover:bg-white/5"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link href="/about" onClick={closeMobile} className="block px-4 py-3 rounded-lg text-sm font-medium text-surface-300 hover:text-white hover:bg-white/5">
              About
            </Link>
            {isLoggedIn ? (
              <button
                onClick={() => { logout(); closeMobile(); }}
                className="w-full text-left px-4 py-3 rounded-lg text-sm font-medium text-accent-rose hover:bg-accent-rose/10"
              >
                Sign Out
              </button>
            ) : (
              <Link href="/dashboard" onClick={closeMobile} className="block px-4 py-3 rounded-lg text-sm font-semibold gradient-text">
                Sign In
              </Link>
            )}
          </div>
        </motion.div>
      )}
    </motion.header>
  );
}
